$(document).ready(function() {
    $(".my-progress-bar").circularProgress({
        line_width: 18,
        color: "#191970",
        starting_position: 50, // 12.00 o' clock position, 25 stands for 3.00 o'clock (clock-wise)
        percent: 0, // percent starts from
        percentage: true,
        text: "One moment please",
    }).circularProgress('animate', 100, 4000);
});
