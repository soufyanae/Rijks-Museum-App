function populate() {
    if(quiz.isEnded ()) {
        showScores();
    }
    else {
        // show question
        var element = document.getElementById("question");
        element.innerHTML = quiz.getQuestionIndex().text;
        
        //show choices
        var choices = quiz.getQuestionIndex().choices;
        for(var i = 0; i< choices.length; i++) {
            var element = document.getElementById("choice" + i);
            element.innerHTML = choices[i];
            guess ("btn" +i, choices[i]);
        }
        
        showProgress(); 
    }
};

function guess (id, guess) {
    var button = document.getElementById(id);
    button.onclick = function() {
        alert("Continuar a " + paint);
        quiz.guess(guess);
        populate();
    }
   
}

function showProgress() {
    var currentQuestionsNumber = quiz.questionsIndex +1;
    var element = document.getElementById("progress");
    element.innerHTML = "Pregunta " + currentQuestionsNumber + " de la " +quiz.questions.length;
     if (currentQuestionsNumber == 1) {
            paint = "De kruisiging, Zaal 0.1";
        } else if (currentQuestionsNumber == 2) {
            paint = "De aanbidding van de koningen, Zaal 0.1";
        } else if (currentQuestionsNumber == 3) {
            paint = "De aanbidding van de koningen, Zaal 0.1";
        } else if (currentQuestionsNumber == 4) {
            paint = "De aanbidding van de koningen, Zaal 0.1";    
        } else if (currentQuestionsNumber == 5) {
            paint = "Pleurants van het praalgraf van Isabella van Bourbon, Zaal 0.1";
        } else if (currentQuestionsNumber == 6) {
            paint = "Tapijt met het wapen van keizer Karel V, Zaal 0.4";
        } else if (currentQuestionsNumber == 7) {
            paint = "De Sint-Elisabethsvloed, Meester van de Heilige Elisabeth-Panelen, Zaal 0.4";
        } else if (currentQuestionsNumber == 8) {
            paint = "Het herbergen van de vreemdelingen, Zaal 0.6";
        } else if (currentQuestionsNumber == 9) {
            paint = "Het herbergen van de vreemdelingen, Zaal 0.6";
        }
}

function showScores(){
    var gameOverHtml = "<h1>Resultado</h1>";
    gameOverHtml += "<h2 id = 'score'> Tu puntuación es: " +quiz.score +"</h2>";
    var element = document.getElementById("quiz");
    element.innerHTML = gameOverHtml;
    var element = document.getElementById("picture1").style.visibility = "visible";
    element.innerHTML = gameOverHtml;
};

var questions = [
    new Question("¿En qué período se desarrolló la Edad Media? ", ["1000-1300", "500-1500", "100-600", "1500-2000"], "500-1500"),
    new Question("¿Qué fue central en la Edad Media?", ["Fe", "Dinero", "Poder", "Guerra"], "Fe"),
    new Question("¿Quién o qué son los botín? ", ["Banquero", "Pastores", "Esclavos", "Landheer"], "Landheer"),
    new Question("¿Qué significa centralización? ", ["Nombre de capital", "Administrando desde un punto", "Punto de encuentro", "Destino"], "Administrando desde un punto"),
    new Question("¿Qué tuvieron que hacer los comerciantes a cambio de los derechos de la ciudad? ", ["Pagando impuestos", "Sirviendo al ejército", "obediencia", "Solicitud de pasaporte"], "Pagando impuestos"),
    new Question("¿Qué imperio fue el más grande de la Edad Media?", ["Imperio bizantino", "Imperio franco", "Imperio germánico", "Imperio romano"], "Imperio romano"),
    new Question("¿Quién introdujo la centralización? ", ["Carlomagno", "Napoleón", "Luis XIV", "Hendrickje"], "Carlomagno"),
    new Question("¿Alrededor de qué año en la Edad Media se unieron muchas ciudades? ", ["300", "1000", "1700", "650"], "1000"),
    new Question("¿Por qué terminó la Alta Edad Media? ", ["Pobreza", "La peste", "Desastre natural", "Desaparición del sistema feudal"], "Desaparición del sistema feudal"),
    new Question("¿Por qué los viajes de los comerciantes a menudo eran peligrosos? ", ["Animales salvajes", "Ladrones", "Soldados", "Enfermedades peligrosas"], "Ladrones"),
];


var quiz = new Quiz(questions);

populate();


