function populate() {
    if(quiz.isEnded ()) {
        showScores();
    }
    else {
        // show question
        var element = document.getElementById("question");
        element.innerHTML = quiz.getQuestionIndex().text;
        
        //show choices
        var choices = quiz.getQuestionIndex().choices;
        for(var i = 0; i< choices.length; i++) {
            var element = document.getElementById("choice" + i);
            element.innerHTML = choices[i];
            guess ("btn" +i, choices[i]);
        }
        
        showProgress(); 
    }
};

function guess (id, guess) {
    var button = document.getElementById(id);
    button.onclick = function() {
        alert("Continue to " + paint);
        quiz.guess(guess);
        populate();
    }
   
}

function showProgress() {
    var currentQuestionsNumber = quiz.questionsIndex +1;
    var element = document.getElementById("progress");
    element.innerHTML = "Question " + currentQuestionsNumber + " of the " +quiz.questions.length;
    if (currentQuestionsNumber == 1) {
            paint = "Vrede van Munster, Zaal 2.1";
        } else if (currentQuestionsNumber == 2) {
            paint = "Kan met deksel, Zaal 2.1";
        } else if (currentQuestionsNumber == 3) {
            paint = "Willem I, prins van Oranje, Zaal 2.1";
        } else if (currentQuestionsNumber == 4) {
            paint = "De terugkomst in Amsterdam van de tweede expeditie naar Oost-Indië, Zaal 2.9";
        } else if (currentQuestionsNumber == 5) {
            paint = "De handelsloge van de VOC in Hougly in Bengalen, Zaal 2.9";
        } else if (currentQuestionsNumber == 6) {
            paint = "Het keuren van thee door de handelaren van de VOC, Zaal 2.9";
        } else if (currentQuestionsNumber == 7) {
            paint = "Gezicht op Batavia, Zaal 2.9";
        } else if (currentQuestionsNumber == 8) {
            paint = "De wapens van de VOC en Batavia, Zaal 2.9";
        } else if (currentQuestionsNumber == 9) {
            paint = "Gevangenneming van Johan van Oldenbarnevelt, Zaal 2.9";
        }
}

function showScores(){
    var gameOverHtml = "<h1>Result</h1>";
    gameOverHtml += "<h2 id = 'score'> Your score is: " +quiz.score +"</h2>";
    var element = document.getElementById("quiz");
    element.innerHTML = gameOverHtml;
    var element = document.getElementById("picture1").style.visibility = "visible";
    element.innerHTML = gameOverHtml;
};

var questions = [
    
    new Question ("How is the year 1672 also called?", ["Disaster Year", "Leap Year", "Dry Year", "Lucky Year"], "Disaster Year"),
    new Question ("Why is the 17th century in the Netherlands also called the Golden Age?", ["Many gold finds", "Enlightenment and Wealth", "Continued Silver Age", "French Revolution reached the Netherlands"], "Enlightenment and Wealth "),
    new Question ("How long did the war between the Netherlands and Spain end in 1648", ["80 months", "80 weeks", "80 years", "90 months"], "80 years"),
     new Question ("Which country was the richest in the 17th century?", ["Turkey", "Netherlands", "America", "France"], "Netherlands"),
    new Question ("What makes the Netherlands successful?", ["Science", "Technology", "War", "Trade"], "Trade"),
    new Question ("7. The letters 'VOC' stand for ...", ["Enlightenment Under Control", "United East India Company", "Sail Under Constatine", "Far Under China"], "United East India Company "),
    new Question ("What is the name of one of the most famous ships of the VOC?", ["Bali", "Nova Zembla", "Batavia", "Zilvervloot"], "Batavia"),
    new Question ("When is the VOC established?", ["1640", "1615", "1623", "1602"], "1602"),
    new Question ("Where was Johan van Oldenbarnevelt decapitated", ["Dam", "Ridderzaal", "Eerste Kamer", "Prison"], "Ridderzaal"),
];


var quiz = new Quiz(questions);

populate();


