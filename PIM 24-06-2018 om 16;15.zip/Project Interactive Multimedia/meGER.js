function populate() {
    if(quiz.isEnded ()) {
        showScores();
    }
    else {
        // show question
        var element = document.getElementById("question");
        element.innerHTML = quiz.getQuestionIndex().text;
        
        //show choices
        var choices = quiz.getQuestionIndex().choices;
        for(var i = 0; i< choices.length; i++) {
            var element = document.getElementById("choice" + i);
            element.innerHTML = choices[i];
            guess ("btn" +i, choices[i]);
        }
        
        showProgress(); 
    }
};

function guess (id, guess) {
    var button = document.getElementById(id);
    button.onclick = function() {
        alert("Weiter zu" + paint);
        quiz.guess(guess);
        populate();
    }
   
}

function showProgress() {
    var currentQuestionsNumber = quiz.questionsIndex +1;
    var element = document.getElementById("progress");
    element.innerHTML = "Frage " + currentQuestionsNumber + " der " +quiz.questions.length;
     if (currentQuestionsNumber == 1) {
            paint = "De kruisiging, Zaal 0.1";
        } else if (currentQuestionsNumber == 2) {
            paint = "De aanbidding van de koningen, Zaal 0.1";
        } else if (currentQuestionsNumber == 3) {
            paint = "De aanbidding van de koningen, Zaal 0.1";
        } else if (currentQuestionsNumber == 4) {
            paint = "De aanbidding van de koningen, Zaal 0.1";    
        } else if (currentQuestionsNumber == 5) {
            paint = "Pleurants van het praalgraf van Isabella van Bourbon, Zaal 0.1";
        } else if (currentQuestionsNumber == 6) {
            paint = "Tapijt met het wapen van keizer Karel V, Zaal 0.4";
        } else if (currentQuestionsNumber == 7) {
            paint = "De Sint-Elisabethsvloed, Meester van de Heilige Elisabeth-Panelen, Zaal 0.4";
        } else if (currentQuestionsNumber == 8) {
            paint = "Het herbergen van de vreemdelingen, Zaal 0.6";
        } else if (currentQuestionsNumber == 9) {
            paint = "Het herbergen van de vreemdelingen, Zaal 0.6";
        }
}

function showScores(){
    var gameOverHtml = "<h1>Ergebnis</h1>";
    gameOverHtml += "<h2 id = 'score'> Deine Punktzahl ist: " +quiz.score +"</h2>";
    var element = document.getElementById("quiz");
    element.innerHTML = gameOverHtml;
    var element = document.getElementById("picture1").style.visibility = "visible";
    element.innerHTML = gameOverHtml;
};

var questions = [
    new Question("In welcher Periode spielte das Mittelalter? ", ["1000-1300", "500-1500", "100-600", "1500-2000"], "500-1500"),
    new Question("Was war im Mittelalter zentral? ", ["Glaube", "Geld", "Macht", "Krieg"], "Glaube"),
    new Question("Wer oder was sind Plünderer? ", ["Banker", "Shepherds", "Slaves", "Landheer"], "Landheer"),
    new Question("Wat betekent centralisatie? ", ["Name Capital", "Verwalten von einem Punkt", "Treffpunkt", "Ziel"], "Verwalten von einem Punkt"),
    new Question("Was mussten Händler als Gegenleistung für Stadtrechte tun? ", ["Steuern zahlen", "Armee in", "Horror", "Pass beantragen"], "Steuern bezahlen"),
    new Question("Welches Reich war das größte Reich im Mittelalter?", ["Byzantinisches Reich", "Fränkisches Reich", "Germanisches Reich", "Römisches Reich"], "Römisches Reich"),
    new Question("Wer hat die Zentralisierung eingeführt? ", ["Karl der Große", "Napoleon", "Ludwig XIV.", "Hendrickje"], "Karl der Große"),
    new Question("Um welches Jahr im Mittelalter schlossen sich viele Städte an? ", ["300", "1000", "1700", "650"], "1000"),
    new Question("Warum endete das frühe Mittelalter? ", ["Armut", "Die Pest", "Naturkatastrophe", "Verschwundenes Feudalsystem"], "Verschwundenes Feudalsystem"),
    new Question("Warum waren die Reisen von Kaufleuten oft gefährlich? ", ["Wilde Tiere", "Diebe", "Soldaten", "Gefährliche Krankheiten"], "Diebe"),
    
];

var quiz = new Quiz(questions);

populate();


