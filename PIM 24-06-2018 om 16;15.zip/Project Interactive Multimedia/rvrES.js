function populate() {
    if(quiz.isEnded ()) {
        showScores();
    }
    else {
        // show question
        var element = document.getElementById("question");
        element.innerHTML = quiz.getQuestionIndex().text;
        
        //show choices
        var choices = quiz.getQuestionIndex().choices;
        for(var i = 0; i< choices.length; i++) {
            var element = document.getElementById("choice" + i);
            element.innerHTML = choices[i];
            guess ("btn" +i, choices[i]);
        }
        
        showProgress(); 
    }
};

function guess (id, guess) {
    var button = document.getElementById(id);
    button.onclick = function() {
        alert("Continuar a " + paint);
        quiz.guess(guess);
        populate();
    }
   
}

function showProgress() {
    var currentQuestionsNumber = quiz.questionsIndex +1;
    var element = document.getElementById("progress");
    element.innerHTML = "Pregunta " + currentQuestionsNumber + " de la " +quiz.questions.length;
    if (currentQuestionsNumber == 1) {
            paint = "Zelfportret als de apostel Paulus, Eregalerij";
        } else if (currentQuestionsNumber == 2) {
            paint = "De Nachtwacht, Eregalerij";
        } else if (currentQuestionsNumber == 3) {
            paint = "De Nachtwacht, Eregalerij";
        } else if (currentQuestionsNumber == 4) {
            paint = "De Nachtwacht, Eregalerij";
        } else if (currentQuestionsNumber == 5) {
            paint = "Rembrandts zoon Titus in monniksdracht, Eregalerij";
        } else if (currentQuestionsNumber == 6) {
            paint = "Pijprokende man, zaal 2.25";
        } else if (currentQuestionsNumber == 7) {
            paint = "Jonge vrouw in gefantaseerde kleding, zaal 2.8";
        } else if (currentQuestionsNumber == 8) {
            paint = "Zelfportret, Rembrandt van Rijn, zaal 2.8";
        } else if (currentQuestionsNumber == 9) {
            paint = "De verloochening van Petrus, zaal 2.8";
        } 
}

function showScores(){
    var gameOverHtml = "<h1>Resultado</h1>";
    gameOverHtml += "<h2 id = 'score'> Tu puntuación es: " +quiz.score +"</h2>";
    var element = document.getElementById("quiz");
    element.innerHTML = gameOverHtml;
    var element = document.getElementById("picture1").style.visibility = "visible";
    element.innerHTML = gameOverHtml;
};

var questions = [
    new Question("¿Dónde nació Rembrandt?", ["Middelburg", "Leiden", "Amsterdam", "Utrecht"], "Leiden"),
    new Question("¿Cuándo falleció Rembrandt?", ["1602", "1598", "1604", "1669"], "1669"),
    new Question("¿Cuál es el trabajo más famoso de Rembrandt?", ["La guardia nocturna", "los maestros de la muestra", "la novia judía", "el soldado"], "la guardia nocturna"),
    new Question("¿En qué lugar de Rembrandt vivió Ámsterdam durante más tiempo?", ["Keizersgracht", "Rembrandtplein", "Jodenbreestraat", "Westermarkt"], "Jodenbreestraat"),
    new Question("¿Cuándo se creó la Guardia Nocturna?", ["1640-1642", "1615-1617", "1623-1625", "1634-1636"], "1640-1642"),
    new Question("¿¿Cuántos niños tenía Rembrandt?", ["10", "3", "7", "4"], "4"),
    new Question("¿Cuál es el nombre del primer alumno de Rembrandt?", ["Gerri Manhoef", "Jacob van der Wal", "Youssef van de Buurt", "Gerrit Dou"], "Gerrit Dou"),
    new Question("¿Quién fue la primera esposa de Rembrandt?", ["Monica", "Elizabeth", "Saskia", "Hendrickje"], "Saskia"),
    new Question("¿En qué siglo vivió Rembrandt?", ["15o", "16o", "17o", "18o"], "17o"),
    new Question("¿Qué hace que las pinturas de Rembrandt sean tan especiales?", ["Pintura al óleo", "Acuarela", "Clair-obscur", "Naturaleza"], "Clair-obscur"),
];


var quiz = new Quiz(questions);

populate();


