function populate() {
    if(quiz.isEnded ()) {
        showScores();
    }
    else {
        // show question
        var element = document.getElementById("question");
        element.innerHTML = quiz.getQuestionIndex().text;
        
        //show choices
        var choices = quiz.getQuestionIndex().choices;
        for(var i = 0; i< choices.length; i++) {
            var element = document.getElementById("choice" + i);
            element.innerHTML = choices[i];
            guess ("btn" +i, choices[i]);
        }
        
        showProgress(); 
    }
};

function guess (id, guess) {
    var button = document.getElementById(id);
    button.onclick = function() {
        alert("Ga door naar " + paint);
        quiz.guess(guess);
        populate();
    }
   
}

function showProgress() {
    var currentQuestionsNumber = quiz.questionsIndex +1;
    var element = document.getElementById("progress");
    element.innerHTML = "Vraag " + currentQuestionsNumber + " van de " +quiz.questions.length;
     if (currentQuestionsNumber == 1) {
            paint = "De kruisiging, Zaal 0.1";
        } else if (currentQuestionsNumber == 2) {
            paint = "De aanbidding van de koningen, Zaal 0.1";
        } else if (currentQuestionsNumber == 3) {
            paint = "De aanbidding van de koningen, Zaal 0.1";
        } else if (currentQuestionsNumber == 4) {
            paint = "De aanbidding van de koningen, Zaal 0.1";    
        } else if (currentQuestionsNumber == 5) {
            paint = "Pleurants van het praalgraf van Isabella van Bourbon, Zaal 0.1";
        } else if (currentQuestionsNumber == 6) {
            paint = "Tapijt met het wapen van keizer Karel V, Zaal 0.4";
        } else if (currentQuestionsNumber == 7) {
            paint = "De Sint-Elisabethsvloed, Meester van de Heilige Elisabeth-Panelen, Zaal 0.4";
        } else if (currentQuestionsNumber == 8) {
            paint = "Het herbergen van de vreemdelingen, Zaal 0.6";
        } else if (currentQuestionsNumber == 9) {
            paint = "Het herbergen van de vreemdelingen, Zaal 0.6";
        }
}

function showScores(){
    var gameOverHtml = "<h1>Result</h1>";
    gameOverHtml += "<h2 id = 'score'> Jouw score is: " +quiz.score +"</h2>";
    var element = document.getElementById("quiz");
    element.innerHTML = gameOverHtml;
    var element = document.getElementById("picture1").style.visibility = "visible";
    element.innerHTML = gameOverHtml;
};

var questions = [
    new Question("In welke periode speelde de middeleeuwen zich af? ", ["1000-1300", "500-1500", "100-600", "1500-2000"], "500-1500"),
    new Question("Wat stond centraal in de middeleeuwen? ", ["Geloof", "Geld", "Macht", "Oorlog"], "Geloof"),
    new Question("Wie of wat zijn leenmannen? ", ["Bankier", "Herders", "Slaven", "Landheer"], "Landheer"),
    new Question("Wat betekent centralisatie? ", ["Hoofdstad benoemen", "Vanuit één punt besturen", "Meeting point", "Doelwit"], "Vanuit één punt besturen"),
    new Question("Wat moesten kooplieden doen in ruil voor stadsrechten? ", ["Belasting betalen", "Het leger in", "Horigheid", "Paspoort aanvragen"], "Belasting betalen"),
    new Question("Welk rijk was het grootste rijk in de middeleeuwen?", ["Byzantijnse Rijk", "Frankische Rijk", "Germaanse Rijk", "Romeinse Rijk"], "Romeinse Rijk"),
    new Question("Wie introduceerde de centralisatie? ", ["Karel de Grote", "Napoleon", "Lodewijk XIV", "Hendrickje"], "Karel de Grote"),
    new Question("Rond welk jaar in de middeleeuwen kwamen er veel steden bij? ", ["300", "1000", "1700", "650"], "1000"),
    new Question("Waarom eindigde de vroege middeleeuwen? ", ["Armoede", "De pest", "Natuurramp", "Uiteenvallen feodale stelsel"], "Uiteenvallen feodale stelsel"),
    new Question("Waardoor waren de reizen van kooplieden vaak gevaarlijk? ", ["Wilde dieren", "Dieven", "Soldaten", "Gevaarlijke ziektes"], "Dieven"),

];


var quiz = new Quiz(questions);

populate();


