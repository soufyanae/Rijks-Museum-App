function populate() {
    if(quiz.isEnded ()) {
        showScores();
    }
    else {
        // show question
        var element = document.getElementById("question");
        element.innerHTML = quiz.getQuestionIndex().text;
        
        //show choices
        var choices = quiz.getQuestionIndex().choices;
        for(var i = 0; i< choices.length; i++) {
            var element = document.getElementById("choice" + i);
            element.innerHTML = choices[i];
            guess ("btn" +i, choices[i]);
        }
        
        showProgress(); 
    }
};

function guess (id, guess) {
    var button = document.getElementById(id);
    button.onclick = function() {
        alert("Ga door naar " + paint);
        quiz.guess(guess);
        populate();
    }
   
}

function showProgress() {
    var currentQuestionsNumber = quiz.questionsIndex +1;
    var element = document.getElementById("progress");
    element.innerHTML = "Vraag " + currentQuestionsNumber + " van de " +quiz.questions.length;
     if (currentQuestionsNumber == 1) {
            paint = "Vrede van Munster, Zaal 2.1";
        } else if (currentQuestionsNumber == 2) {
            paint = "Kan met deksel, Zaal 2.1";
        } else if (currentQuestionsNumber == 3) {
            paint = "Willem I, prins van Oranje, Zaal 2.1";
        } else if (currentQuestionsNumber == 4) {
            paint = "De terugkomst in Amsterdam van de tweede expeditie naar Oost-Indië, Zaal 2.9";
        } else if (currentQuestionsNumber == 5) {
            paint = "De handelsloge van de VOC in Hougly in Bengalen, Zaal 2.9";
        } else if (currentQuestionsNumber == 6) {
            paint = "Het keuren van thee door de handelaren van de VOC, Zaal 2.9";
        } else if (currentQuestionsNumber == 7) {
            paint = "Gezicht op Batavia, Zaal 2.9";
        } else if (currentQuestionsNumber == 8) {
            paint = "De wapens van de VOC en Batavia, Zaal 2.9";
        } else if (currentQuestionsNumber == 9) {
            paint = "Gevangenneming van Johan van Oldenbarnevelt, Zaal 2.9";
        }
}

function showScores(){
    var gameOverHtml = "<h1>Result</h1>";
    gameOverHtml += "<h2 id = 'score'> Jouw score is: " +quiz.score +"</h2>";
    var element = document.getElementById("quiz");
    element.innerHTML = gameOverHtml;
    var element = document.getElementById("picture1").style.visibility = "visible";
    element.innerHTML = gameOverHtml;
};

var questions = [
    new Question("Hoe heet de vrede die in 1648 werd gesloten tussen Spanje en Nederland? ", ["Vrede van Munster", "Bevrijdingsdag", "Vrede van Dam", "Verdrag van Versailles"], "Vrede van Munster"), 
    new Question("Hoe wordt het jaar 1672 ook wel genoemd? ", ["Rampjaar", "Schrikkeljaar", "Droge jaar", "Geluksjaar"], "Rampjaar"),
    new Question("Welk land was in de 17e eeuw het rijkst? ", ["Turkije", "Nederland", "Amerika", "Frankrijk"], "Nederland"),
    new Question("Hoe lang duurde de oorlog tussen Nederland en Spanje dat eindigde in 1648", ["80 maanden", "80 weken", "80 jaar", "90 maanden"], "80 jaar"),
    new Question("Waarom wordt de 17e eeuw in Nederland ook wel de Gouden Eeuw genoemd?", ["Veel goudvondsten", "Verlichting en Rijkdom", "Vervolg Zilvere Eeuw", "Franse Revolutie bereikte Nederland"], "Verlichting en Rijkdom"),
    new Question("Waardoor is Nederland succesvol geworden? ", ["Wetenschap", "Technologie", "Oorlog", "Handel"], "Handel"),
    new Question("De letters 'VOC' staan voor… ", ["Verlichting Onder Controle", "Verenigde Oost-Indische Compagnie", "Varen Onder Constatijn", "Ver Onder China"], "Verenigde Oost-Indische Compagnie"),
    new Question("Hoe heet een van de bekendste schepen van de VOC?", ["Bali", "Nova Zembla", "Batavia", "Zilvervloot"], "Batavia"),
    new Question("Wanneer is de VOC opgericht? ", ["1640", "1615", "1623", "1602"], "1602"),
    new Question("Waar werd Johan van Oldenbarnevelt onthoofd", ["Dam", "Ridderzaal", "Eerste Kamer", "Gevangenis"], "Ridderzaal"),
];


var quiz = new Quiz(questions);

populate();


