function populate() {
    if(quiz.isEnded ()) {
        showScores();
    }
    else {
        // show question
        var element = document.getElementById("question");
        element.innerHTML = quiz.getQuestionIndex().text;
        
        //show choices
        var choices = quiz.getQuestionIndex().choices;
        for(var i = 0; i< choices.length; i++) {
            var element = document.getElementById("choice" + i);
            element.innerHTML = choices[i];
            guess ("btn" +i, choices[i]);
        }
        
        showProgress(); 
    }
};

function guess (id, guess) {
    var button = document.getElementById(id);
    button.onclick = function() {
        alert("Weiter zu " + paint);
        quiz.guess(guess);
        populate();
    }
   
}

function showProgress() {
    var currentQuestionsNumber = quiz.questionsIndex +1;
    var element = document.getElementById("progress");
    element.innerHTML = "Frage " + currentQuestionsNumber + " der " +quiz.questions.length;
      if (currentQuestionsNumber == 1) {
            paint = "Vrede van Munster, Zaal 2.1";
        } else if (currentQuestionsNumber == 2) {
            paint = "Kan met deksel, Zaal 2.1";
        } else if (currentQuestionsNumber == 3) {
            paint = "Willem I, prins van Oranje, Zaal 2.1";
        } else if (currentQuestionsNumber == 4) {
            paint = "De terugkomst in Amsterdam van de tweede expeditie naar Oost-Indië, Zaal 2.9";
        } else if (currentQuestionsNumber == 5) {
            paint = "De handelsloge van de VOC in Hougly in Bengalen, Zaal 2.9";
        } else if (currentQuestionsNumber == 6) {
            paint = "Het keuren van thee door de handelaren van de VOC, Zaal 2.9";
        } else if (currentQuestionsNumber == 7) {
            paint = "Gezicht op Batavia, Zaal 2.9";
        } else if (currentQuestionsNumber == 8) {
            paint = "De wapens van de VOC en Batavia, Zaal 2.9";
        } else if (currentQuestionsNumber == 9) {
            paint = "Gevangenneming van Johan van Oldenbarnevelt, Zaal 2.9";
        }
}

function showScores(){
    var gameOverHtml = "<h1>Ergebnis</h1>";
    gameOverHtml += "<h2 id = 'score'> Deine Punktzahl ist: " +quiz.score +"</h2>";
    var element = document.getElementById("quiz");
    element.innerHTML = gameOverHtml;
    var element = document.getElementById("picture1").style.visibility = "visible";
    element.innerHTML = gameOverHtml;
};

var questions = [
    new Question("Wie heißt der Friede, der 1648 zwischen Spanien und den Niederlanden geschlossen wurde?", ["Frieden von Münster", "Tag der Befreiung", "Frieden des Staudamms", "Vertrag von Versailles"], "Frieden von Münster"),
    new Question("Wie heißt das Jahr 1672?", ["Katastrophenjahr", "Schaltjahr", "Trockenes Jahr", "Glücksjahr"], "Katastrophenjahr"),
    new Question("Warum wird das 17. Jahrhundert in den Niederlanden auch Goldenes Zeitalter genannt?", ["Viele Goldfunde", "Aufklärung und Reichtum", "Fortgesetztes Silberzeitalter", "Französische Revolution erreichte die Niederlande"], "Aufklärung und Reichtum") ,
    new Question("Wie lange dauerte der Krieg zwischen den Niederlanden und Spanien, der 1648 endete", ["80 Monate", "80 Wochen", "80 Jahre", "90 Monate"], "80 Jahre"),
    new Question("Welches Land war das reichste im 17. Jahrhundert?", ["Türkei", "Holland", "Amerika", "Frankreich"], "Holland"),
    new Question("Warum werden die Niederlande erfolgreich?", ["Wissenschaft", "Technologie", "Krieg", "Handel"], "Handel"),
    new Question("Die Buchstaben VOC stehen für ...", ["Aufklärung unter Kontrolle", "Vereinigte Ostindische Kompanie", "Segeln unter Konstatine", "Weit unter China"], "Vereinigte Ostindische Kompanie"),
    new Question("Wie heißt eines der berühmtesten Schiffe der VOC?", ["Bali", "Nova Zembla", "Batavia", "Zilvervloot"], "Batavia"),
    new Question("Wann wurde die VOC gegründet?", ["1640", "1615", "1623", "1602"], "1602"),
    new Question("Wo wurde Johan van Oldenbarnevelt enthauptet", ["Dam", "Ridderzaal", "Eerste Kamer", "Gefängnis"], "Ridderzaal"),
];

var quiz = new Quiz(questions);

populate();


