function populate() {
    if(quiz.isEnded ()) {
        showScores();
    }
    else {
        // show question
        var element = document.getElementById("question");
        element.innerHTML = quiz.getQuestionIndex().text;
        
        //show choices
        var choices = quiz.getQuestionIndex().choices;
        for(var i = 0; i< choices.length; i++) {
            var element = document.getElementById("choice" + i);
            element.innerHTML = choices[i];
            guess ("btn" +i, choices[i]);
        }
        
        showProgress(); 
    }
};

function guess (id, guess) {
    var button = document.getElementById(id);
    button.onclick = function() {
        alert("Ga door naar " + paint);
        quiz.guess(guess);
        populate();
    }
   
}

function showProgress() {
    var currentQuestionsNumber = quiz.questionsIndex +1;
    var element = document.getElementById("progress");
    element.innerHTML = "Vraag " + currentQuestionsNumber + " van de " +quiz.questions.length;
    if (currentQuestionsNumber == 1) {
            paint = "Zelfportret als de apostel Paulus, Eregalerij";
        } else if (currentQuestionsNumber == 2) {
            paint = "De Nachtwacht, Eregalerij";
        } else if (currentQuestionsNumber == 3) {
            paint = "De Nachtwacht, Eregalerij";
        } else if (currentQuestionsNumber == 4) {
            paint = "De Nachtwacht, Eregalerij";
        } else if (currentQuestionsNumber == 5) {
            paint = "Rembrandts zoon Titus in monniksdracht, Eregalerij";
        } else if (currentQuestionsNumber == 6) {
            paint = "Pijprokende man, zaal 2.25";
        } else if (currentQuestionsNumber == 7) {
            paint = "Jonge vrouw in gefantaseerde kleding, zaal 2.8";
        } else if (currentQuestionsNumber == 8) {
            paint = "Zelfportret, Rembrandt van Rijn, zaal 2.8";
        } else if (currentQuestionsNumber == 9) {
            paint = "De verloochening van Petrus, zaal 2.8";
        } 
}

function showScores(){
    var gameOverHtml = "<h1>Result</h1>";
    gameOverHtml += "<h2 id = 'score'> Jouw score is: " +quiz.score +"</h2>"
    ;
    var element = document.getElementById("quiz");
    element.innerHTML = gameOverHtml;
    var element = document.getElementById("picture1").style.visibility = "visible";
    element.innerHTML = gameOverHtml;
    
};




var questions = [
    new Question("Waar is Rembrandt geboren?", ["Middelburg", "Leiden", "Amsterdam", "Utrecht"], "Leiden"),
    new Question("Wanneer was Rembrandt overleden?", ["1602", "1598", "1604", "1669"], "1669"),
    new Question("Wat is Rembrandts beroemdste werk?", ["de Nachtwacht", "de staalmeesters", "het Joodse Bruidje", "de Soldaat"], "de Nachtwacht"),
    new Question("Waar in Amsterdam woonde Rembrandt het langst?", ["Keizersgracht", "Rembrandtplein", "Jodenbreestraat", "Westermarkt"], "Jodenbreestraat"),
    new Question("Wanneer is de Nachtwacht gemaakt?", ["1640-1642", "1615-1617", "1623-1625", "1634-1636"], "1640-1642"),
    new Question("Hoeveel kinderen had Rembrandt?", ["10", "3", "7", "4"], "4"),
    new Question("Hoe heet Rembrandts eerste leerling?", ["Gerri Manhoef", "Jacob van der Wal", "Youssef van de Buurt", "Gerrit Dou"], "Gerrit Dou"),
    new Question("Wie was Rembrandts eerste vrouw?", ["Monica", "Elizabeth", "Saskia", "Hendrickje"], "Saskia"),
    new Question("In welke eeuw leefde Rembrandt?", ["15e", "16e", "17e", "18e"], "17e"),
    new Question("Wat maakt de schilderijen van Rembrandt zo bijzonder?", ["Olieverf", "Waterverf", "Clair-obscur", "Natuur"], "Clair-obscur"),
];


var quiz = new Quiz(questions);

populate();


