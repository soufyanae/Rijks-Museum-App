function populate() {
    if(quiz.isEnded ()) {
        showScores();
    }
    else {
        // show question
        var element = document.getElementById("question");
        element.innerHTML = quiz.getQuestionIndex().text;
        
        //show choices
        var choices = quiz.getQuestionIndex().choices;
        for(var i = 0; i< choices.length; i++) {
            var element = document.getElementById("choice" + i);
            element.innerHTML = choices[i];
            guess ("btn" +i, choices[i]);
        }
        
        showProgress(); 
    }
};

function guess (id, guess) {
    var button = document.getElementById(id);
    button.onclick = function() {
        alert("Continue to " + paint);
        quiz.guess(guess);
        populate();
    }
   
}

function showProgress() {
    var currentQuestionsNumber = quiz.questionsIndex +1;
    var element = document.getElementById("progress");
    element.innerHTML = "Question " + currentQuestionsNumber + " of the " +quiz.questions.length;
     if (currentQuestionsNumber == 1) {
            paint = "De kruisiging, Zaal 0.1";
        } else if (currentQuestionsNumber == 2) {
            paint = "De aanbidding van de koningen, Zaal 0.1";
        } else if (currentQuestionsNumber == 3) {
            paint = "De aanbidding van de koningen, Zaal 0.1";
        } else if (currentQuestionsNumber == 4) {
            paint = "De aanbidding van de koningen, Zaal 0.1";    
        } else if (currentQuestionsNumber == 5) {
            paint = "Pleurants van het praalgraf van Isabella van Bourbon, Zaal 0.1";
        } else if (currentQuestionsNumber == 6) {
            paint = "Tapijt met het wapen van keizer Karel V, Zaal 0.4";
        } else if (currentQuestionsNumber == 7) {
            paint = "De Sint-Elisabethsvloed, Meester van de Heilige Elisabeth-Panelen, Zaal 0.4";
        } else if (currentQuestionsNumber == 8) {
            paint = "Het herbergen van de vreemdelingen, Zaal 0.6";
        } else if (currentQuestionsNumber == 9) {
            paint = "Het herbergen van de vreemdelingen, Zaal 0.6";
        }
}

function showScores(){
    var gameOverHtml = "<h1>Result</h1>";
    gameOverHtml += "<h2 id = 'score'> Your score is: " +quiz.score +"</h2>";
    var element = document.getElementById("quiz");
    element.innerHTML = gameOverHtml;
    var element = document.getElementById("picture1").style.visibility = "visible";
    element.innerHTML = gameOverHtml;
};

var questions = [
    new Question("In what period did the Middle Ages took place?", ["1000-1300", "500-1500", "100-600", "1500-2000"], "500-1500"),
    new Question("What was central in the Middle Ages? ", ["Faith", "Money", "Power", "War"], "Faith"),
    new Question("Who or what are lootmen? ", ["Banker", "Shepherds", "Slaves", "Landheer"], "Landheer"),
    new Question("What does centralization mean?", ["Name Capital", "Managing from one point", "Meeting point", "Target"], "Managing from one point"),
    new Question("What did merchants have to do in exchange for city rights? ", ["Pay taxes", "Army in", "Horror", "Request passport"], "Pay tax"),
    new Question("Which empire was the greatest empire in the Middle Ages?", ["Byzantine Empire", "Frankish Empire", "Germanic Empire", "Roman Empire"], "Roman Empire"),
    new Question("Who introduced the centralization? ", ["Charlemagne", "Napoleon", "Louis XIV", "Hendrickje"], "Charlemagne"),
    new Question("Around which year in the Middle Ages did many cities join? ", ["300", "1000", "1700", "650"], "1000"),
    new Question("Why did the early Middle Ages end? ", ["Poverty", "The Plague", "Natural Disaster", "Disappearing feudal system"], "Disappearing feudal system"),
    new Question("Why were the travels of merchants often dangerous? ", ["Wild Animals", "Thieves", "Soldiers", "Dangerous Diseases"], "Thieves"),
    
    
];


var quiz = new Quiz(questions);

populate();


